# -*- coding: utf-8 -*-
"""Tests of skbase.validate functionality."""
